---
name: User Story
about: Create a User Story for Agile Planning
title: ''
labels: ''
assignees: ''

---

**As a** [role]  
**I need** [function]  
**So that** [benefit]  

**Details & Assumptions:** 
* ...

**Acceptance Criteria:**

```gherkin
Given [some initial state]
When [some event]
Then [some measurable outcome]
```
